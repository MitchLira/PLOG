%Pr0jet0


board([
		[[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[l1,0,0,0,1,a,1,0,1,0],[t,0,0,0,t,t,t,0,0,0],[l2,0,1,0,0,a,0,1,0,1],[t,0,0,0,t,t,t,0,0,0],[l3,0,0,0,0,a,0,1,1,1],[t,0,0,0,t,t,t,0,0,0],[c,1,0,1,0,a,0,1,0,1],[t,0,0,0,t,t,t,0,0,0],[l3,0,0,0,0,a,0,1,1,1],[t,0,0,0,t,t,t,0,0,0],[l2,0,1,0,0,a,0,1,0,1],[t,0,0,0,t,t,t,0,0,0],[l1,0,0,0,1,a,1,0,1,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0]],
		[[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0]],
		[[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[p1,0,0,0,0,a,0,0,1,1],[t,0,0,0,t,t,t,0,0,0],[p2,0,0,0,0,a,0,1,0,1],[t,0,0,0,t,t,t,0,0,0],[p3,0,1,0,0,a,0,0,1,0],[t,0,0,0,t,t,t,0,0,0],[p2,0,0,0,0,a,0,1,0,1],[t,0,0,0,t,t,t,0,0,0],[p1,0,0,0,0,a,0,1,1,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0]],
		[[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0]],
		[[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[s,0,0,0,0,a,0,0,1,0],[t,0,0,0,t,t,t,0,0,0],[s,0,0,0,0,a,0,0,1,0],[t,0,0,0,t,t,t,0,0,0],[s,0,0,0,0,a,0,0,1,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0]],
		[[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0]],
		[[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[l2,2,0,2,0,b,0,0,2,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0]],
		[[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0]],
		[[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0]],
		[[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0]],
		[[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[l2,0,1,0,0,a,0,1,0,1],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0]],
		[[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0]],
		[[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[s,0,2,0,0,b,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[s,0,2,0,0,b,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[s,0,2,0,0,b,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0]],
		[[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0]],
		[[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[p1,0,2,2,0,b,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[p2,2,0,2,0,b,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[p3,0,2,0,0,b,0,0,2,0],[t,0,0,0,t,t,t,0,0,0],[p2,2,0,2,0,b,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[p1,2,2,0,0,b,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0]],
		[[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0],[z,be,0,bd,bd,0,be],[z,0,bv,0,0,bv,0]],
		[[z,0,0,0,0,0,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[l1,0,2,0,2,b,2,0,0,0],[t,0,0,0,t,t,t,0,0,0],[l2,2,0,2,0,b,0,0,2,0],[t,0,0,0,t,t,t,0,0,0],[l3,2,2,2,0,b,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[c,2,0,2,0,b,0,2,0,2],[t,0,0,0,t,t,t,0,0,0],[l3,2,2,2,0,b,0,0,0,0],[t,0,0,0,t,t,t,0,0,0],[l2,2,0,2,0,b,0,0,2,0],[t,0,0,0,t,t,t,0,0,0],[l1,0,2,0,2,b,2,0,0,0],[t,0,0,0,t,t,t,0,0,0],[z,0,0,0,0,0,0,0,0,0]]
]).

player(1).

% translates dos simbolos das peças
translate(1,'+'). % 1 significa simbolo para jogador 1
translate(2,'*'). % 2 significa simbolo para jogador 2
translate(0,' '). % representa um espaço

% translates dos simbolos que reprensentam os caminhos
translate(t,'-'). % representa um traço
translate(bv,'|'). % barra vertical
translate(bd,'/'). % barra lateral direito
translate(be,'\\'). % barra lateral esquerdo

% translates dos ids dos jogadores
translate(a,'1').
translate(b,'2').



%===========================================================================================================
%============================================	REGRAS		================================================
%===========================================================================================================

% DISPLAY DE UM TABULEIRO

displayBoard(Board) :-
							display_letras_colunas,
							display_board(Board,1),
							nl, nl, nl.

display_letras_colunas :-
							nl, nl, nl,
							write('  a     b     c     d     e     f     g     h     i '),
							nl, nl.


display_board([L1,L2|Ls], N) :-
							write(' '),
							display_linha(L1, 'Top'),	% 	Display Parte de cima de cada peça
							write(N),
							display_linha(L1, 'Mid'),	% 	Display Parte do meio de cada peça
							write(' '),
							display_linha(L1, 'Down'),	% 	Display Parte de baixo de cada peça
							write(' '),
							display_linha(L2, 'Top'),	% 	Display Parte de cima dos caminhos entre cada linha de peças
							write(' '),
							display_linha(L2, 'Mid'),	% 	Display Parte de baixo dos caminhos entre cada linha de peças
							N1 is N+1,
							display_board(Ls, N1).





display_board([L1|[]], N) :- 		% 	Chama esta função quando na recursividade quando é para fazer display da última linha
							write(' '),
							display_linha(L1, 'Top'),	% 	Estas 3 linhas seguintes é como anteriormente
							write(N),
							display_linha(L1, 'Mid'),
							write(' '),
							display_linha(L1, 'Down'),
							display_board([]).

display_board([]) :- nl.		% 	Condição de paragem para o display


% Vamos apenas ignorar o primeiro elemento da lista
display_linha([], _Type) 	:-
							nl.

display_linha([L1|Ls], 'Top') :-
							L1 = [_|L2],
							junta_pecas(L2,_Res),
							display_linha(Ls, 'Top').

% Vamos ignorar o primeiro e a parte de cima, isto é, os 3 seguintes
display_linha([L1|Ls], 'Mid'):-
							L1 = [_,_,_,_|L2],
							junta_pecas(L2,_Res),
							display_linha(Ls, 'Mid').


% Vamos ignorar o primeiro, a parte de cima e a parte do meio, isto é, os 6 seguintes
display_linha([L1|Ls], 'Down') :-
							L1 = [_,_,_,_,_,_,_|L2],
							junta_pecas(L2,_Res),
							display_linha(Ls , 'Down').




% Faz append das partes todas, isto é, faz append das partes de cima das peças e depois display destas mesmas
junta_pecas([E1,E2,E3|_Ls],Res) :-
							append([E1,E2,E3],[],Res),
							display_peca(Res).



display_peca([E1|Es]) :-
							translate(E1,P),
							write(P),
							display_peca(Es).

display_peca([]) :-
							write('').
