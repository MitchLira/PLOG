get_casa(Board, Coluna, Linha, Casa) :-
							nth0(Linha,Board, Line),
							nth0(Coluna, Line, Casa).

get_linha(Board, Linha, Res)  :-
							nth0(Linha, Board, Res).

set_casa(Indice, Elemento,Lista, NewLista):-
							length(AuxL, Indice),
							append(AuxL, [_|E], Lista),
							append(AuxL, [Elemento| E], NewLista).

valida_casa(Casa):-
							Casa=[_,0,0,0,0,0,0,0,0,0].

set_board_casa(X, Y, Casa, Board, NewBoard) :-
							get_linha(Board, Y, LinhaY),
							set_casa(X, Casa, LinhaY, ResLinhaY),
							set_casa(Y, ResLinhaY, Board, NewBoard).

mover_peca(Board, Xantes, Yantes, Orientacao,NovoBoard) :-
							valida_direcao(Board, Xantes, Yantes, Orientacao, X, Y),
							valida_coordenada(X, Y),
							get_casa(Board,X, Y, CasaVazia), %guarda a casa para a qual a peça se vai mexer
							valida_casa(CasaVazia), %verifico se essa casa esta vazia
							get_casa(Board, Xantes, Yantes, Peca), %guardo a peca que quero mexer
							set_board_casa(X,Y, Peca, Board, MoveBoard),%movo a peca
							set_board_casa(Xantes, Yantes, CasaVazia, MoveBoard, NovoBoard). %apago a casa onde a peca estava

valida_coordenada(X,Y) :-
							X>=0,
							X=<16,
							Y>=0,
							Y=<16,
							0 is X mod 2,
							0 is Y mod 2.


%verifica se a peça pode tem o indicador direcional conforme a direcao
%se se verificar sucesso vai buscar as coordenadas para a qual a peça se vai mexer
valida_direcao(Board,Xantes,Yantes, Orientacao, X, Y) :-
							valida_orientacao(Board,Xantes,Yantes,Orientacao),
							get_novas_coordenadas(Orientacao, Xantes, Yantes, X,Y).

%verifica se o bit da lista da peca e do jogador 1 ou 2 e esta ativo
valida_orientacao(Board, X, Y, Ori):-
							get_casa(Board,X,Y,Casa),
							write(Casa),nl,write(Ori),nl,
							nth0(Ori, Casa, Bit),
							write(Bit),nl,
							Bit == 2.

valida_orientacao(Board, X, Y, Ori):-
							get_casa(Board,X,Y,Casa),
							write(Casa),nl,write(Ori),nl,
							nth0(Ori, Casa, Bit),
							write(Bit),nl,
							Bit == 1.

%conforme a orientacao dada retorna as coordenadas para a qual a peça se vai mexer
get_novas_coordenadas(N, X, Y, NewX, NewY) :-
							((N =:= 1, NewX is X-2, NewY is Y-2);
							(N =:= 2, NewX is X, NewY is Y-2);
							(N =:= 3, NewX is X+2, NewY is Y-2);
							(N =:= 4, NewX is X-2, NewY is Y);
							(N =:= 6, NewX is X+2, NewY is Y);
							(N =:= 7, NewX is X-2, NewY is Y+2);
							(N =:= 8, NewX is X, NewY is Y+2);
							(N =:= 0, NewX is X+2, NewY is Y+2)).

numero_casas(Board, X, Y, Ncasas) :-				%ler o id_peca para de seguida calcular quantas casas pode andar com aquela peça
							get_casa(Board, X, Y, Casa),
							nth0(0, Casa, Idpeca),
							convertContadorDir(Idpeca, Ncasas).


valida_NcasasEscolhidas(NcasasPossiveis, NcasasEscolhidas) :-		% verifica se o numero de casas escolhido pode ser efetuado
							NcasasEscolhidas >= 1,
							NcasasEscolhidas =< NcasasPossiveis.
